License is currently being determined.
